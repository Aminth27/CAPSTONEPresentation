A Pen created at CodePen.io. You can find this one at https://codepen.io/mikun/pen/YWgqEX.

 Original idea: https://www.behance.net/gallery/38203579/MrBara-Fashion-Website

A slider animation with Pokemon design.